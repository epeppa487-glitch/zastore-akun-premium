'use client';
import { useEffect, useState } from 'react';

export default function Invoice({ params }: any) {
  const [status, setStatus] = useState<any>('pending');

  async function check() {
    const res = await fetch('/api/pay-status', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ invoice: params.invoice })
    }).then(r=>r.json());
    setStatus(res.status);
  }

  useEffect(() => {
    check();
    const i = setInterval(check, 10000);
    return () => clearInterval(i);
  }, []);

  return (
    <main style={{ padding: 20 }}>
      <h2>Invoice {params.invoice}</h2>
      <p>Status: {status}</p>
    </main>
  );
}
