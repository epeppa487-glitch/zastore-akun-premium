'use client';
import { useEffect, useState } from 'react';

export default function Home() {
  const [products, setProducts] = useState<any[]>([]);

  useEffect(() => {
    fetch('/api/products').then(r => r.json()).then(d => {
      if (d.success) {
        setProducts(d.data.map((p:any) => ({...p, price: p.price * 2})));
      }
    });
  }, []);

  async function buy(p:any) {
    const pay = await fetch('/api/pay', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount: p.price })
    }).then(r=>r.json());

    window.location.href = `/invoice/${pay.invoice}`;
  }

  return (
    <main style={{ padding: 20 }}>
      <h1>Premku Store</h1>
      {products.map(p => (
        <div key={p.id}>
          <b>{p.name}</b><br/>
          Rp {p.price}<br/>
          <button onClick={()=>buy(p)}>Beli</button>
        </div>
      ))}
    </main>
  );
}
