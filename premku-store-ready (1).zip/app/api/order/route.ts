import { premku } from '@/lib/premku';
export async function POST(req: Request) {
  const body = await req.json();
  return Response.json(await premku('order', body));
}
