import { premku } from '@/lib/premku';
export async function GET() {
  return Response.json(await premku('products'));
}
