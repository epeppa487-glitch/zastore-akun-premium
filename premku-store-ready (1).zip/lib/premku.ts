const API_URL = process.env.PREMKU_API_URL!;
const API_KEY = process.env.PREMKU_API_KEY!;

export async function premku(endpoint: string, data = {}) {
  const res = await fetch(`${API_URL}/${endpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ api_key: API_KEY, ...data }),
    cache: 'no-store'
  });
  return res.json();
}
